#!/usr/bin/env python
#   -*- coding: utf-8 -*-

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'daggit',
        version = '0.5.0',
        description = '',
        long_description = '',
        long_description_content_type = None,
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        keywords = '',

        author = '',
        author_email = '',
        maintainer = '',
        maintainer_email = '',

        license = 'MIT License',

        url = '',
        project_urls = {},

        scripts = ['scripts/daggit'],
        packages = [
            '.',
            'daggit',
            'daggit.contrib',
            'daggit.core',
            'daggit.core.base',
            'daggit.core.io',
            'daggit.core.nodes',
            'daggit.core.oplib',
            'daggit.runtime'
        ],
        namespace_packages = [],
        py_modules = ['__init__'],
        entry_points = {},
        data_files = [],
        package_data = {},
        install_requires = [
            'apache-airflow[postgres]==1.10.4',
            'pytest-runner==5.1',
            'dateutils==0.6.6',
            'h5py==2.9.0',
            'PyYAML==5.3.1',
            'boto==2.49.0',
            'boto3==1.9.130',
            'botocore==1.12.130',
            'scikit-learn==0.20.2',
            'pandas==0.25.1',
            'numpy==1.17.1',
            'Pint==0.9',
            'scipy==1.3.1',
            'six==1.12.0',
            'xgboost==0.90',
            'Sphinx==2.2.0',
            'tox==3.13.2',
            'networkx==2.3',
            'findspark==1.3.0',
            'Werkzeug<1.0.0',
            'py2neo==4.3.0',
            'Pygments==2.3.1',
            'SQLAlchemy==1.3.15',
            'Flask==1.1.2',
            'mock==3.0.5',
            'pyspark==2.4.4',
            'tables==3.6.1'
        ],
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        python_requires = '',
        obsoletes = [],
    )
